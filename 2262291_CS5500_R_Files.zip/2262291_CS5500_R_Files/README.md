# MSRDimRed
Dimensionality reduction for molecular simulation data in R
